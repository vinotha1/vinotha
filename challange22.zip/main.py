#define the base class player
class player:
    def play(self):
      print("The player is playing cricket.")
      #define the derived class batman
      class batman(player):
        def play(self):
          print("The batman is batting.")
          #define the derived class bowlwer
          class bowler(player):
            def play(self)
            print("The bpwler is bowling.")
            batman=batsman()
            bowler=bowler()
            