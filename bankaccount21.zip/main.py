def withdraw(self):
    amount=float(input("Enter amount to withdraw:"))
  if self.balance>=amount:
    self.balance-=amount
    print("you withdraw:",amount)
  else:
print("Insufficient balance")