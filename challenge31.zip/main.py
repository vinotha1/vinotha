def linear search product(product list,targrt product)
indices=[]
for index,product in enumerate(product list):
  if product==target product:
  indices.append(index)
  return indices
  (variable)product:list(str)
  products=("shoes,""boot","
  target="shoes"
  target="apple"
  result=linear shoes product(prouduct,target)
  print(result)
  